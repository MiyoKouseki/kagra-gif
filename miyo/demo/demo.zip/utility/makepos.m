function pos = makepos(x0,y0,dx,dy)
pos=[x0-dx/2,y0-dy/2,x0+dx/2,y0+dy/2];
